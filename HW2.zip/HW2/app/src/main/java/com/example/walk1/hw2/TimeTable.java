package com.example.walk1.hw2;

import android.app.ActionBar;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Window;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.Calendar;

public class TimeTable extends AppCompatActivity {

    private boolean isLand; // true: landscape, false: potrait

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_time_table);
        init();
    }

    @Override
    public void onConfigurationChanged (Configuration newConfig)
    {
        super.onConfigurationChanged(newConfig);
        // Checks the orientation of the screen
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE)
        {
            isLand = true;
            setContentView(R.layout.activity_time_table_land);
            //Toast.makeText(this, "landscape", Toast.LENGTH_SHORT).show();
            Log.d("orientation", "landscape");
            init();
        }
        else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT)
        {
            isLand = false;
            setContentView(R.layout.activity_main);
            //Toast.makeText(this, "portrait", Toast.LENGTH_SHORT).show();
            Log.d("orientation", "portrait");
            init();
        }
    }

    private void init()
    {
        // highlight day
        LinearLayout today;
        switch (Calendar.getInstance().get(Calendar.DAY_OF_WEEK))
        {
            case 2: // monday
                today = (LinearLayout)findViewById(R.id.Monday);
                if (isLand)
                    today.setBackgroundColor(getResources().getColor(R.color.highlight_land));
                else
                    today.setBackgroundColor(getResources().getColor(R.color.highlight));
                break;
            case 3: // tuesday
                today = (LinearLayout)findViewById(R.id.Tuesday);
                if (isLand)
                    today.setBackgroundColor(getResources().getColor(R.color.highlight_land));
                else
                    today.setBackgroundColor(getResources().getColor(R.color.highlight));
                break;
            case 4: // wednesday
                today = (LinearLayout)findViewById(R.id.Wednesday);
                if (isLand)
                    today.setBackgroundColor(getResources().getColor(R.color.highlight_land));
                else
                    today.setBackgroundColor(getResources().getColor(R.color.highlight));
                break;
            case 5: // thursday
                today = (LinearLayout)findViewById(R.id.Thursday);
                if (isLand)
                    today.setBackgroundColor(getResources().getColor(R.color.highlight_land));
                else
                    today.setBackgroundColor(getResources().getColor(R.color.highlight));
                break;
            case 6: // friday
                today = (LinearLayout)findViewById(R.id.Friday);
                if (isLand)
                    today.setBackgroundColor(getResources().getColor(R.color.highlight_land));
                else
                    today.setBackgroundColor(getResources().getColor(R.color.highlight));
                break;
            default:
                break;
        }

        // initialize Monday time table.
        addSubject(4, 1);
        addSubject("Mobile Programming", 2, 1);
        addSubject("Management Theory", 3, 1);

        // initialize Tuesday time table.
        addSubject("Structure History", 2, 2);
        addSubject(1, 2);
        addSubject("Graphics", 4, 2);

        // initialize Wednesday time table
        addSubject(4, 3);
        addSubject("Mobile Programming", 2, 3);
        addSubject(1, 3);
        addSubject("Software Industry Seminar", 3, 3);

        // initialize Thursday time table
        addSubject(6, 4);
        addSubject("Proto-type", 2, 4);

        // initialize Friday time table
        addSubject(0.5, 5);
        addSubject("Software Engineering", 2.5, 5);

        // hide action bar
        //ActionBar actionBar = getActionBar();
        //actionBar.hide();
    }

    /* create textview without subjects during runtime */
    private void addSubject(double term, int day)
    {
        addSubject("", term, day);
    }

    /* create textview of subject during runtime */
    private void addSubject(String name, double term, int day)
    {
        TextView subject = new TextView(this);
        subject.setText(name);

        /* change dp into px */
        float width = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 60, getResources().getDisplayMetrics());
        float height = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, (int) (60*term), getResources().getDisplayMetrics());

        /* set the size of TextView */

        subject.setWidth((int) width);
        subject.setHeight((int) height);
        subject.setGravity(17);

        /* set the border of TextView */
        if (!name.equals("")) {
            GradientDrawable gd = new GradientDrawable();
            if (isLand) // with landscape mode, show landscape color
                gd.setColor(getResources().getColor(R.color.box_land));
            else    // with portrait mode, show portrait color
                gd.setColor(getResources().getColor(R.color.box));
            gd.setCornerRadius(5);
            gd.setStroke(1, Color.rgb(41, 72, 105));    //
            subject.setBackgroundDrawable(gd);
        }

        LinearLayout table;
        switch (day)
        {
            case 1: // put the text view on monday
                table = (LinearLayout)findViewById(R.id.Monday);
                table.addView(subject);
                break;
            case 2: // put the text view on tuesday
                table = (LinearLayout)findViewById(R.id.Tuesday);
                table.addView(subject);
                break;
            case 3: // put the text view on wednesday
                table = (LinearLayout)findViewById(R.id.Wednesday);
                table.addView(subject);
                break;
            case 4: // put the text view on thursday
                table = (LinearLayout)findViewById(R.id.Thursday);
                table.addView(subject);
                break;
            case 5: // put the text view on friday
                table = (LinearLayout)findViewById(R.id.Friday);
                table.addView(subject);
                break;
        }

        /* implementing margin of textview */
        LinearLayout.LayoutParams params = (LinearLayout.LayoutParams) subject.getLayoutParams();
        params.setMargins(1, 1, 0, 0);
        subject.setLayoutParams(params);
    }
}
