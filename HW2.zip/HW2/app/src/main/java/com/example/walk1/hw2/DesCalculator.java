package com.example.walk1.hw2;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class DesCalculator extends AppCompatActivity implements View.OnClickListener {

    private Button bt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_des_calculator);
        bt = (Button)findViewById(R.id.btRunCalc);
        bt.setOnClickListener(this);
    }

    @Override
    public void onClick(View v)
    {
        startActivityForResult(new Intent("com.example.walk1.hw2.CALCULATOR"), 0000);   // Request Code: 0000
    }

    @Override
    public void onActivityResult(int request, int result, Intent data)
    {
        if (result == RESULT_OK)
            Toast.makeText(getApplicationContext(), data.getStringExtra("result"), Toast.LENGTH_SHORT).show();
    }


}
