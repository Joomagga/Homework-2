package com.example.walk1.hw2;

import android.app.ListActivity;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Toast;

public class MainActivity extends ListActivity
{

    String[] activities = {"Time Table", "Tip Counter", "Calculator", "Change Password"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //setContentView(R.layout.activity_main);

        /* activity list */
        ListView lv = getListView();
        lv.setChoiceMode(ListView.CHOICE_MODE_SINGLE);
        lv.setTextFilterEnabled(true);
        MyAdapter adapter = new MyAdapter(this, activities);
        setListAdapter(adapter);
    }

    @Override
    protected void onListItemClick(ListView l, View v, int position, long id)
    {
        super.onListItemClick(l, v, position, id);

        switch (position)
        {
            case 0: // start timetable activity
                startActivity(new Intent("com.example.walk1.hw2.DESTIME"));
                break;
            case 1: // start tip calculator activity
                startActivity(new Intent("com.example.walk1.hw2.DESTIPC"));
                break;
            case 2: // start Calculator activity
                startActivity(new Intent("com.example.walk1.hw2.DESCALC"));
                break;
            case 3: // start change password activity
                startActivity(new Intent("com.example.walk1.hw2.CHANGEPASSWORD"));
                break;

        }
    }
}
