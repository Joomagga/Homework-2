package com.example.walk1.hw2;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LogIn extends AppCompatActivity {

    EditText[] PIN = new EditText[4];   // 4 PINs

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);

        initEdt();
    }

    // initialize EditText
    void initEdt()
    {
        PIN[0] = (EditText) findViewById(R.id.pw1);
        PIN[1] = (EditText) findViewById(R.id.pw2);
        PIN[2] = (EditText) findViewById(R.id.pw3);
        PIN[3] = (EditText) findViewById(R.id.pw4);

        PIN[0].requestFocus();
        PIN[0].addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            // when backspace deleted
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0) {
                    PIN[1].setText("");
                    PIN[1].requestFocus();
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        PIN[1].addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            // when backspace deleted
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0) {
                    PIN[2].setText("");
                    PIN[2].requestFocus();
                } else
                    PIN[0].requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        PIN[2].addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            // when backspace deleted
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0) {
                    PIN[3].setText("");
                    PIN[3].requestFocus();
                } else
                    PIN[1].requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        PIN[3].addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() != 0) {
                    if (checkPIN())
                    {
                        // if PIN is right, go next activity
                        startActivity(new Intent("com.example.walk1.hw2.MAINACTIVITY"));
                        Log.d("Debug", "Check PIN is right");
                    }
                    else {
                        // else toast error message
                        Toast.makeText(getApplicationContext(), "Check your PIN", Toast.LENGTH_SHORT);
                        Log.d("Debug", "Check PIN is wrong");
                    }
                } else
                    PIN[2].requestFocus();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });
    }

    boolean checkPIN() {
        SharedPreferences mySharedPreferences = getSharedPreferences("Default", Activity.MODE_PRIVATE);
        //is there an existing Preferences from previous executions of this app?

        if (mySharedPreferences != null && mySharedPreferences.contains("PIN")) { //object and key found, show all saved values
            String typed = "";
            for (int i = 0; i < 4; i = i + 1)
                typed = typed.concat(PIN[i].getText().toString());

            if (typed.equals(mySharedPreferences.getString("PIN", "")))
                return true;
        } else {
            SharedPreferences.Editor editor = mySharedPreferences.edit();
            editor.putString("PIN", "0000");
            editor.commit();
        }
        return false;
    }
}
